package calculadora;

public class Calculadora {

	public int SomaInteiros(int a, int b) {
	return a+b;
	}
	public int subtraiInteiros(int a, int b) {
		return a-b;
	}
	public int multiplicaInteiros(int a, int b) {
		return a*b;
	}
	public int dividiInteiros(int a, int b) {
		return a/b;
	}

}
